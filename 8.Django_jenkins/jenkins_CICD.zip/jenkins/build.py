# -*- coding: UTF-8 -*-
# @File    :  build.py
# @Time    :  2019-07-30
# @Author  :  Duan.rj


import sys
import commands
import os
import shutil



# bash command
def bash(cmd):
    return commands.getstatusoutput(cmd)[1]


# 判断项目构建完成后的文件或目录是否存在
def returnBuidResults(jenkinsHomeDir, projectName, projectType):
    # 判断项目类型
    if projectType == 'vue':
        fileeType = ''
    elif projectType == 'node':
        fileeType = '.tar.gz'
    elif projectType == 'java':
        fileeType = '.jar'
    else:
        print('没有支持的项目类型!')
        sys.exit(1)

    # 判断是否构建成功
    if os.path.exists('%s/%s%s' % (jenkinsHomeDir, projectName, fileeType)):
        print("构建项目\"%s\"成功!" % projectName)
    else:
        print("构建项目\"%s\"失败!" % projectName)
        sys.exit(1)

# Vue项目构建过程
def buildVue(tagNum, projectBackDir, projectCodeTagNum, jenkinsHomeDir, projectName, projectType):
    # 构建打包
    os.chdir(jenkinsHomeDir)
    bash("cnpm install")
    bash("cnpm run build")

    # # 如果有tag标签，执行备份工作，项目回滚，生产部署用到
    # if tagNum != str(0):
    #     if os.path.exists('%s/%s' % (projectBackDir, projectCodeTagNum)):
    #         shutil.rmtree('%s/%s' % (projectBackDir, projectCodeTagNum))
    #
    #     shutil.copytree('%s/%s' % (jenkinsHomeDir, projectName), '%s/%s' % (projectBackDir, projectCodeTagNum))

    returnBuidResults(jenkinsHomeDir, projectName, projectType)

# Node项目构建过程
def buildNode(tagNum, projectBackDir, projectCodeTagNum, jenkinsHomeDir, projectName, projectType):
    os.chdir(jenkinsHomeDir)
    if projectName == 'e-eduspace-service-web-v4':
        bash('npm install')
    elif projectName == 'bookCollege-mgr':
        bash('cnpm install && cnpm install -g gulp && gulp')




# Java项目构建过程
def buildJava(jenkinsHomeDir):
    os.chdir(jenkinsHomeDir)

# 获取项目名称及构建类型
def codeBuild(projectNameList, envType, tagNum, jenkinsHomeDir, projectType, buildName):
    os.chdir(jenkinsHomeDir)
    projectList = projectNameList.split(',')
    for projectName in projectList:
        # 初始化备份目录
        projectBackDir = '/opt/Backup/%s' % projectName
        # 初始化备份tag目录
        projectCodeTagNum = '%s_%s' % (projectName, tagNum)
        # 依据项目类型执行构建
        if projectType == 'vue':
            buildVue(tagNum, projectBackDir, projectCodeTagNum, jenkinsHomeDir, projectName, projectType)
        elif projectType == 'node':
            buildNode()
        elif projectType == 'java':
            buildJava(jenkinsHomeDir)
        else:
            print("没找到项目类型\"%s!\"" % projectType)
            sys.exit(1)



# 主入口
def main():
    projectNameList = sys.argv[1]
    envType = sys.argv[2]
    tagNum = sys.argv[3]
    jenkinsHomeDir = sys.argv[4]
    projectType = sys.argv[5]
    buildName = sys.argv[6]

    codeBuild(projectNameList, envType, tagNum, jenkinsHomeDir, projectType, buildName)



if __name__ == '__main__':
    main()