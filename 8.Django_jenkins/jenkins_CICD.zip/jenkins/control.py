# -*- coding: UTF-8 -*-
# @File    :  control.py
# @Time    :  2019-08-02
# @Author  :  Duan.rj


import commands
import sys

projectNameList = (sys.argv[1]).split(',')
envType = sys.argv[2]
tagNum = sys.argv[3]
buildName = sys.argv[4]
projectType = sys.argv[5]
jenkinsCacheDir = sys.argv[6]
ansibleDir = '/opt/App/ansible'

# bash
def bash(cmd):
    return commands.getstatusoutput(cmd)


def returnMessage(cmd, message):
    if cmd[0] == 0:
        print('info: ' + message + ' SUCCESS!')
    else:
        print('error: ' + message + ' ERROR!')
        print("详细信息:")
        print(cmd[1])
        sys.exit(1)


def control(projectName):
    ansibleTab = projectName + envType
    ansibleFile = ansibleDir + '/' + ansibleTab + 'Hosts'
    projectCacheDir = '/opt/JenkinsCache/' + projectName

    # 客户端代码缓存目录确认
    cmd = bash('ansible %s -i %s -m shell -a "mkdir -p %s"' % (ansibleTab, ansibleFile, projectCacheDir))
    returnMessage(cmd, '初始化客户端缓存目录')

    # 客户端配置目录确认
    cmd = bash('ansible %s -i %s -m shell -a "mkdir -p /opt/{Service,Log/%s,Backup/%s,Script/%s,App}"' % (ansibleTab, ansibleFile, projectName, projectName, projectName))
    returnMessage(cmd, '客户端配置目录确认')

    # install rsync
    cmd = bash('ansible %s -i %s -m shell -a "yum -y install rsync"' % (ansibleTab, ansibleFile))
    returnMessage(cmd, 'install rsync')

    # 删除客户端缓存目录中旧代码
    cmd = bash('ansible %s -i %s -m shell -a "rm -rf %s/*"' % (ansibleTab, ansibleFile, projectCacheDir))
    returnMessage(cmd, '删除客户端缓存目录中旧代码')

    # 更新客户端缓存目录代码
    cmd = bash('ansible %s -i %s -m copy -a "src=%s/%s.tar.gz dest=%s"' % (ansibleTab, ansibleFile, projectCacheDir, projectName, projectCacheDir))
    returnMessage(cmd, '更新客户端缓存目录代码')

    # 更新客户端部署代码
    cmd = bash('ansible %s -i %s -m copy -a "src=/opt/Script/ops/Script/jenkins/deploy.sh dest=/opt/Script"' % (ansibleTab, ansibleFile))
    returnMessage(cmd, '更新客户端部署代码')

    # 更新客户端启动服务脚本
    if projectType != 'vue':
        cmd = bash('ansible %s -i %s -m copy -a "src=/opt/Script/ops/Script/%s.sh dest=/opt/Script/%s"' % (ansibleTab, ansibleFile, projectName, projectName))
        returnMessage(cmd, '更新客户端启动服务脚本')

    # 执行客户端部署操作
    #print('ansible %s -i %s -m shell -a "/bin/bash /opt/Script/deploy.sh %s %s %s"' % (ansibleTab, ansibleFile, projectName, envType, projectType))
    cmd = bash('ansible %s -i %s -m shell -a "/bin/bash /opt/Script/deploy.sh %s %s %s"' % (ansibleTab, ansibleFile, projectName, envType, projectType))
    returnMessage(cmd, '执行客户端部署操作')
for projectName in projectNameList:
    control(projectName)