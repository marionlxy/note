# -*- coding: UTF-8 -*-
# @File    :  codeBuild.py
# @Time    :  2019-08-01
# @Author  :  Duan.rj


import sys
import commands
import os



tagNum = sys.argv[1]
jenkinsHomeDir = sys.argv[2]
buildCmd = eval(repr(sys.argv[3]).replace('_', ' '))
projectNameList = (sys.argv[4]).split(',')


# bash command
def bash(cmd):
    return commands.getstatusoutput(cmd)


def codeBuild(jenkinsHomeDir, buildCmd, projectName):
    if projectName == 'e-eduspace-service-web-v4':
        jenkinsHomeDir = jenkinsHomeDir + '/' + projectName
    os.chdir(jenkinsHomeDir)
    cmd = bash(buildCmd)

    # if 'BUILD SUCCESS' or 'Build complete' in cmd:
    if cmd[0] == 0:
        print("INFO: 项目编译 SUCCESS!")
    else:
        print("ERROR: 项目编译 ERROR!")
        print("详细信息:")
        print(cmd[1])
        sys.exit(1)

for projectName in projectNameList:
    codeBuild(jenkinsHomeDir, buildCmd, projectName)