#!/bin/bash
# @Time    :  2019-08-06
# @Author  :  Duan.rj



# sh diagnosis-live-service.sh restart env

SERVER=diagnosis-live-service
APP_HOME=/opt/Service/${SERVER}
JAVA_HOME=/usr/local/jdk
ENV=${2}



if [[ ${ENV} == 'prod' ]];then
    mx=2048
    ms=2048
else
    mx=512
    ms=512
fi

ulimit -n 10240


# start function
start(){
    if [[ ${ENV} == '' ]];then help; exit 1;fi
    nohup ${JAVA_HOME}/bin/java  -Xmx${mx}m -Xms${ms}m -Xmn512M -XX:MetaspaceSize=256M -XX:MaxMetaspaceSize=256M -Dfile.encoding=UTF-8 -Dspring.profiles.active=${ENV}  -jar ${APP_HOME}/${SERVER}.jar  >> /opt/Log/${SERVER}/${SERVER}.log   &
    echo `ps -ef|grep java |grep ${APP_HOME}|awk '{print $2}'` > ${APP_HOME}/${SERVER}.pid
}

# stop function
stop(){
    PID=$(cat ${APP_HOME}/${SERVER}.pid)
    kill -9 ${PID}
}


help(){
    printf "arg is Null or Error. Run Example:\n /bin/bash ${0} start/restart prod/test\n"
}


case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        stop
        start
        ;;
    none)
        ;;
    *)
        printf "Usage: %s {start|stop|restart}\n"
        exit 1
        ;;
esac