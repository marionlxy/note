#!/bin/bash
# @Time    :  2019-07-24
# @Author  :  Duan.rj


projectName=${1}
envType=${2}
projectType=${3}
fileOwner=java
ansibleTab=${projectName}${envType}
projectCacheDir=/opt/JenkinsCache/${projectName}
codeDir=/opt/Service
#srcFile=${projectCacheDir}/${projectName}.tar.gz


cd ${projectCacheDir}
ls -l ${projectCacheDir}
tar -xf ${projectName}.tar.gz
rm -rf ${projectCacheDir}/${projectName}.tar.gz



if [[ ${projectType} == "vue" ]];then
    projectNameDir=${codeDir}/${ansibleTab}
    if [[ ! -d ${projectNameDir} ]];then mkdir -p ${projectNameDir};fi
else
    projectNameDir=${codeDir}/${projectName}
fi

if [[ ! -d ${projectNameDir} ]];then mkdir ${projectNameDir};fi





# stop service
if [[ ${projectType} != "vue" ]];then
    if [[ `ps aux |grep ${projectNameDir}|grep -v grep` != '' ]];then
        /bin/bash /opt/Script/${projectName}/${projectName}.sh stop ${envType}
    fi
fi



# 删除代码目录
if [[ ${projectType} == "vue" ]];then
    rm -rf ${projectNameDir}/index.html
    rm -rf ${projectNameDir}/static
elif [[ ${projectType} == "java" ]];then
    # create ${fileOwner} user
    if [[ `egrep "^${fileOwner}" /etc/group` == '' ]];then
        groupadd ${fileOwner}
    elif [[ `egrep "^${fileOwner}" /etc/passwd` == '' ]];then
        useradd ${fileOwner} -g ${fileOwner}
    fi
    # ${projectName}.war 部署
    if [[ -f "${projectNameDir}/webapps/${projectName}.war" ]];then
        rm -rf ${projectNameDir}/webapps/${projectName}*
    else
        # ${projectName}.jar 部署
        rm -rf ${projectNameDir}/${projectName}.jar
    fi
elif [[ ${projectType} == "node" ]];then
    rm -rf ${projectNameDir}/*
else
    echo "no projectType!!"
    exit 1
fi





# 部署服务
if [[ ${projectType} != "java" ]];then
    \cp -R ${projectCacheDir}/${projectName}/* ${projectNameDir}
    if [[ ${projectType} == "node" ]];then
        \cp -R /opt/Backup/${projectName}/*.js /opt/Service/${projectName}/utils
#        chown -R ${fileOwner}.${fileOwner} /opt/{Service,Log,Script,Backup}/${projectName}
    fi
else
    if [[ -d "${projectNameDir}/webapps" ]];then
        \cp ${projectCacheDir}/${projectName}.war ${projectNameDir}/webapps
    else
        \cp ${projectCacheDir}/${projectName}.jar ${projectNameDir}
    fi
    # init dubbo dir
    if [[ ! -d "/opt/.dubbo" ]];then
        mkdir -p /opt/.dubbo
        chown -R ${fileOwner}.${fileOwner} /opt/.dubbo
    fi

    chown -R ${fileOwner}.${fileOwner} /opt/{Service,Log,Script,Backup}/${projectName}

fi
# 启动服务
if [[ ${projectType} != "vue" ]];then
    runuser -l ${fileOwner} -c "/bin/bash /opt/Script/${projectName}/${projectName}.sh restart ${envType}"
fi
# 删除缓存区代码
#rm -rf ${projectCacheDir}/*