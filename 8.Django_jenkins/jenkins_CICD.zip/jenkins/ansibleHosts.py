# -*- coding: UTF-8 -*-
# @File    :  ansibleHosts.py
# @Time    :  2019/9/26
# @Author  :  Duan.rj



import sys
import json
import os
import urllib
import commands


# global values
dataLineList = []
jsonStr = {}
jsonList = []
packageUrl = 'http://sde/download/MySQL-python.tar.gz'
initDir = {'packageDir': '/opt/Package',
           'ansibleHostsDir': '/opt/App/ansible'}
ansibelFile = '%s/hosts' % initDir['ansibleHostsDir']
mysqlconnDist = {
    'url': '192.168.1.67',
    'user': 'ops',
    'passwd': 'Ddjeis&s12',
    'port': 3306,
    'dbname': 'ops',
    'charset': "charset='utf8'",
}


'''
Mysql table create SQL:

/*
 Navicat Premium Data Transfer

 Source Server         : jenkinsOnline
 Source Server Type    : MySQL
 Source Server Version : 50629
 Source Host           : 47.95.194.154:3006
 Source Schema         : ops

 Target Server Type    : MySQL
 Target Server Version : 50629
 File Encoding         : 65001

 Date: 24/05/2019 13:56:49
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ansible_hosts
-- ----------------------------
DROP TABLE IF EXISTS `ansible_hosts`;
CREATE TABLE `ansible_hosts` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT NULL COMMENT 'ip',
  `ssh_port` varchar(255) DEFAULT NULL COMMENT 'ssh port',
  `project_name` varchar(255) DEFAULT NULL COMMENT '项目名称',
  `env` varchar(255) DEFAULT NULL COMMENT '环境(dev:开发，test:测试，prod:生产)',
  `gateway` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;
'''



# init dir
for i in initDir.values():
    if not os.path.exists(i):
        os.makedirs(i)


# bash command
def bash(cmd):
    return commands.getstatusoutput(cmd)[1]


# import MySQLdb
try:
    import MySQLdb
except BaseException:
    urllib.urlretrieve(
        packageUrl,
        '%s/MySQL-python.tar.gz' %
        initDir['packageDir'])
    bash('yum -y install mysql-devel gcc python-devel')
    bash('cd /opt/Package/ && tar -xf MySQL-python.tar.gz')
    bash(' cd /opt/Package/MySQL-python && python setup.py build && python setup.py install')
    import MySQLdb


class mysqlOption(object):
    def __init__(self, argv, projectName, env, data):
        self.argv = argv
        self.projectName = projectName
        self.env = env
        self.data = data

        # if env == 'prod' or env == 'beta' or env == 'rollback':
        #     mysqlconnDist['url'] = '172.16.0.108'
        #     mysqlconnDist['port'] = 3006
            # mysqlconnDist['user'] = '',
            # mysqlconnDist['passwd'] = '',
            # mysqlconnDist['dbname'] = ''

        # connect mysql
        db = MySQLdb.connect(host=mysqlconnDist['url'], user=mysqlconnDist['user'], passwd=mysqlconnDist['passwd'],
                             db=mysqlconnDist['dbname'], port=mysqlconnDist['port'], charset='utf8')
        if self.argv == 'select':
            if self.env == 'rollback': self.env = 'test'
            self.selectDate(self.projectName, self.env, db)
        elif self.argv == 'update' and self.data != '':
            self.updateDate(self.data, db)
        else:
            help()

    def updateHostsFile(self, projectName, env, ssh_port, ip, gatewayIp):
        projectNameTab = '[%s%s]' % (projectName, env)
        # update hosts
        if dataLineList == []:
            dataLineList.append(projectNameTab)
        ansibleFileHostStr = "%s    ansible_ssh_port=%s    ansible_ssh_common_args='-o ProxyCommand=" % (ip, ssh_port) + '"ssh -q -p%s root@%s nc %%h %%p"' % (ssh_port, gatewayIp) + "'"
        lines = str(ansibleFileHostStr)
        if lines not in dataLineList:
            dataLineList.append(lines)

        dataLineStr = '\n'.join(dataLineList)

        ansibelFile = '%s/%s%sHosts' % (initDir['ansibleHostsDir'], projectName,env)
        with open(ansibelFile, 'w+') as f:
            f.write(dataLineStr)

        jsonStr['projectName'] = projectName
        jsonStr['env'] = env
        jsonStr['ip'] = ip
        jsonStr['ssh_port'] = ssh_port

        jsonList.append(jsonStr)


    # select and print data to json
    def selectDate(self, projectName, env, db):
        sql = 'select * from %s.ansible_hosts where project_name="%s" and env="%s"' % (
            mysqlconnDist['dbname'], projectName, env)

        ipList = []
        gatewayList = []
        jsonData = []
        try:
            cur = db.cursor()
            cur.execute(sql)
            data = cur.fetchall()

        except BaseException:
            db.rollback()
            sys.exit(1)

        for row in data:
            result = {}
            result['ip'] = row[1]
            result['ssh_port'] = row[2]
            result['project_name'] = row[3]
            result['env'] = row[4]
            result['gateway'] = row[5]
            jsonData.append(result)
            ipList.append(row[1])
            # if env == 'prod' or env == 'beta':
            #     gatewayList.append(row[5])
            gatewayList.append(row[5])

        # cur.close()
        db.close()
        for dataDist in jsonData:
            self.updateHostsFile(
                projectName,
                env,
                dataDist['ssh_port'],
                dataDist['ip'],
                dataDist['gateway']
            )
            print(
                "get date from db, projectName: %s IP: %s" %
                (projectName, dataDist['ip']))


        # ssh jump config
        # if env == 'prod' or env == 'beta':
        #     if os.path.exists('/root/.ssh/config'):
        #         os.remove('/root/.ssh/config')
        #
        #     with open('/root/.ssh/config', 'a+') as f:
        #         for i in range(len(ipList)):
        #             f.write(
        #                 'Host %s\n\tUser root\n\tPort 33115\n\tHostName %s\n\nHost %s\n\tHostname %s\n\tUser root\n\tPort 33115\n\tProxyCommand ssh -q -p33115 root@%s nc %%h %%p\n\n\n' %
        #                 (gatewayList[i], gatewayList[i], ipList[i], ipList[i], gatewayList[i]))




    def updateDate(self, data, db):
        for jsondata in data:
            project_name = str(jsondata['project_name'])
            ip = str(jsondata['ip'])
            ssh_port = str(jsondata['ssh_port'])
            env = str(jsondata['env'])

            sql = 'select * from %s.ansible_hosts where project_name="%s" and ip="%s" and env="%s"' % (
                mysqlconnDist['dbname'], project_name, ip, env)

            try:
                cur = db.cursor()
                cur.execute(sql)
                datar = cur.fetchall()

            except BaseException:
                db.rollback()
                sys.exit(1)

            # update mysql
            if datar == ():
                sql = 'insert into %s.ansible_hosts (ip,project_name,ssh_port,env) values ("%s","%s","%s","%s")' % (
                    mysqlconnDist['dbname'], ip, project_name, ssh_port, env)
                try:
                    cur = db.cursor()
                    cur.execute(sql)
                    db.commit()
                except BaseException:
                    db.rollback()
                    sys.exit(1)
            else:
                print(
                    'The data already exists(ip:"%s"  projectName:"%s" env:"%s")!' %
                    (ip, project_name, env))

        cur.close()
        db.close()


def help():
    print("Example:\n")
    print("python %s select assessmentWeb dev\n" % (sys.argv[0]))
    print("python %s update '{\"project_name\":\"jeecp\",\"ip\":\"192.168.10.210\",\"ssh_port\":2323,\"env\":\"dev\"}'\n" % (
        sys.argv[0]))
    print("python %s update data.json" % sys.argv[0])
    sys.exit(1)


def main():
    argvList = ['select', 'update']

    if len(sys.argv[1:]) == 0 or sys.argv[1] not in argvList:
        help()
    else:
        argv = sys.argv[1]

    if argv == argvList[0]:
        data = ''
        projectName = sys.argv[2]
        env = sys.argv[3]
    elif argv == argvList[1]:
        projectName = ''
        env = ''
        if sys.argv[2] == 'data.json':
            with open('data.json') as f:
                data = json.load(f)
        else:
            try:
                data = json.loads(sys.argv[2])
            except Exception:
                help()
    else:
        help()

    mysqlOption(argv, projectName, env, data)


if __name__ == '__main__':
    main()
