# -*- coding: UTF-8 -*-
# @File    :  codeReady.py
# @Time    :  2019-07-31
# @Author  :  Duan.rj


"""
- tag为0

  jenkinsHome/project目录下copy代码包至jenkinsHomeCache
  srcDir = jenkinsHomeDir
   java srcDir = jenkinsHomeDir/projectName/target

  decDir = jenkinsHomeCache

- tag 不为 0

  1. back/project目录中存在相同tagNum

     copy代码包至jenkinsHomeCache

     srcDir = backupDir/project/projectName_tagNum.tar.gz
     decDir = jenkinsHomeCache

  2. back目录中不存在tagNum
        1. cp jenkinsHome/project/projectName_tag.tar.gz back/projectDir/projectName
            srcDir = jenkinsHome/project_tag
            decDir = back/project
        2. cp jenkinsHome/project/project_tag.tar.gz jenkinsHomeCache/projectName
            srcDir = jenkinsHome/project
            decDir = jenkinsHomeCache

/var/lib/jenkins/workspace/JAVAdiagnosis-system-manager/target/diagnosis-system-manager.jar
/var/lib/jenkins/workspace/JAVAdiagnosis-exam-service/diagnosis-exam-service/target/diagnosis-exam-service.jar
/var/lib/jenkins/workspace/JAVAwebusiness/webusiness/target/webusiness.war
/var/lib/jenkins/workspace/JAVAeeduspace-assessment/target/eeduspace-assessment.jar
"""


import sys
import os
import shutil
import commands

projectNameList = (sys.argv[1]).split(',') # ['projectName1', 'projectName...']
envType = sys.argv[2] # dev/test/prod
tagNum = sys.argv[3] # 20190817_t1
jenkinsHomeDir = sys.argv[4] # /var/lib/jenkins/workspace/${buildName}
projectType = sys.argv[5] # vue/java/node
backupDir = sys.argv[6] # /opt/Backup
jenkinsCacheDir = sys.argv[7] # /opt/JenkinsCache




def bash(cmd):
    return commands.getstatusoutput(cmd)[1]




def codeReady(projectName, envType, tagNum, jenkinsHomeDir, projectType):
    # java项目构建目录确认
    def _getJavaHomeDir(projectName):
        if os.path.exists(jenkinsHomeDir + '/target'):
            javaHomeDir = jenkinsHomeDir + '/target'
        else:
            javaHomeDir = jenkinsHomeDir + '/' + projectName + '/target'
        return javaHomeDir


    # 项目构建成功的代码目录
    def _jenkinsHomeSwitch(srcDirValue):
        return {
            "java": _getJavaHomeDir(projectName),
            "vue": jenkinsHomeDir,
            "node": jenkinsHomeDir,
        }.get(srcDirValue, "error!")

    # 代码打包
    def _getTarFile(tarDir, projectName, tagNum, projectType):
        os.chdir(tarDir)

        if tagNum == '0':
            if projectType == 'java':
                if os.path.exists(tarDir + '/%s.jar' % projectName):
                    bash('tar -zcf %s.tar.gz %s.jar' % (projectName, projectName))
                elif os.path.exists(tarDir + '/%s.war' % projectName):
                    bash('tar -zcf %s.tar.gz %s.war' % (projectName, projectName))
            else:
                bash('tar -zcf %s.tar.gz %s' % (projectName, projectName))
        else:
            if projectType == 'java':
                if os.path.exists(tarDir + '/%s.jar' % projectName):
                    bash('tar -zcf %s_%s.tar.gz %s.jar' % (projectName, tagNum, projectName))
                elif os.path.exists(tarDir + '/%s.war' % projectName):
                    bash('tar -zcf %s.tar.gz %s.war' % (projectName, projectName))

            else:
                bash('tar -zcf %s_%s.tar.gz %s' % (projectName, tagNum, projectName))

    # 判断代码_tag.tar.gz文件是否存在
    def _getTagFile(projectDir, projectFile):
        projectFilePath = projectDir + '/' + projectFile
        if os.path.exists(projectFilePath):
            return True
        else:
            return False

    # 代码位置就绪
    def _codeOption(srcDir, decDir, projectName, tagNum, option=0):
        os.chdir(srcDir)
        if tagNum == '0':
            shutil.move('%s/%s.tar.gz' % (srcDir, projectName), '%s/%s.tar.gz' % (decDir, projectName))
        else:
            if option == 0:
                shutil.move('%s/%s_%s.tar.gz' % (srcDir, projectName, tagNum), decDir)
                #shutil.move('%s/%s.tar.gz' % (srcDir, projectName), '%s/%s_%s.tar.gz' % (decDir, projectName, tagNum))
            else:
                shutil.copy('%s/%s_%s.tar.gz' % (srcDir, projectName, tagNum), '%s/%s.tar.gz' % (decDir, projectName))

    # 初始代码源/目标位置
    srcDir = _jenkinsHomeSwitch(projectType)
    decDir = jenkinsCacheDir + '/' + projectName
    if not os.path.exists(decDir): os.mkdir(decDir)

    projectNameTagFile = projectName + '_' + tagNum + '.tar.gz'

    # 打包代码
    _getTarFile(srcDir, projectName, tagNum, projectType)
    # 是否tag部署，0:branch  other: tag
    if tagNum == '0':
        _codeOption(srcDir, decDir, projectName, tagNum)
    else:
        ddecDir = backupDir + '/' + projectName
        if not os.path.exists(ddecDir): os.mkdir(ddecDir)
        # if not _getTagFile(ddecDir, projectNameTagFile):
        #     _codeOption(srcDir, ddecDir, projectName, tagNum)
        if not _getTagFile(ddecDir, projectNameTagFile) and envType != "dev":
            print("ERROR: tag没找到，请先部署开发环境验证!")
            sys.exit(1)
        elif not _getTagFile(ddecDir, projectNameTagFile) and envType == "dev":
            _codeOption(srcDir, ddecDir, projectName, tagNum)
            _codeOption(ddecDir, decDir, projectName, tagNum, option=1)
        else:
            print("WARING: tagNum\"%s\"已存在，将部署之前版本!" % tagNum)
            decDirD = jenkinsCacheDir + '/' + projectName
            _codeOption(ddecDir, decDirD, projectName, tagNum, option=1)

    # 代码准备是否有异常
    if (projectName + '.tar.gz') in os.listdir(decDir):
        print('INFO: 项目"%s"代码准备 SUCCESS!' % projectName)
    else:
        print('ERROR: 项目"%s"代码准备 ERROR!' % projectName)
        sys.exit(1)


# tag为0不能部署生产环境
if tagNum == '0' and envType == 'prod':
    print("ERROR: 部署生产环境tagNum不能为0")
    sys.exit(1)

# 多线程启动
for projectName in projectNameList:
    codeReady(projectName, envType, tagNum, jenkinsHomeDir, projectType)