# -*- coding: UTF-8 -*-
# @File    :  codeGetIp.py
# @Time    :  2019-08-01
# @Author  :  Duan.rj


import sys
import commands




projectNameList = (sys.argv[1]).split(',')
envType = sys.argv[2]


# bash
def bash(cmd):
    return commands.getstatusoutput(cmd)


for projectName in projectNameList:
    cmd = bash('python /opt/Script/ops/Script/jenkins/ansibleHosts.py select %s %s' % (projectName, envType))
    if cmd[0] == 0:
        print("info: " + cmd[1] + " SUCCESS!")
    else:
        print("error,详细信息:")
        print(cmd[1])
        sys.exit(1)