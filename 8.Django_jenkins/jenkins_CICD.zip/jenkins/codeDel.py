# -*- coding: UTF-8 -*-
# @File    :  delCode.py
# @Time    :  2019-07-30
# @Author  :  Duan.rj


import sys
import os
import shutil


jenkinsHomeDir = sys.argv[1]
projectNameList = (sys.argv[2]).split(',')
projectType = sys.argv[3]
tagNum = sys.argv[4]
backupDir = sys.argv[5]
projectNameListUnremove = ['lianheguonewlogin', 'newlogin']



def codeOption(projectType, projectName):
    try:
        if projectType == 'java':
            os.remove('%s/%s/target/%s.jar' % (jenkinsHomeDir, projectName, projectName))
        elif projectType == 'node':
            pass
        else:
            if projectName not in projectNameListUnremove:
                shutil.rmtree('%s/%s' % (jenkinsHomeDir, projectName))
        print("INOF: 项目\"%s\"旧代码删除 SUCCESS!" % projectName)
    except Exception, e:
        print(e)
        print("WARING: 项目\"%s\"旧代码不存在或已删除!" % projectName)


def delCode(projectName, tagNum, projectType):
    projectNameBackDir = '%s/%s' % (backupDir, projectName)

    # 判断备份目录中是否有(PROJECTNAME_TAGNUM.tar.gz)文件
    if os.path.exists('%s/%s_%s.tar.gz' % (projectNameBackDir, projectName, tagNum)):
        print("WARING: tag:\"%s\"已经存在，将部署此Tag!")
    # 备份不存在
    else:
        codeOption(projectType, projectName)

[delCode(projectName, tagNum, projectType) for projectName in projectNameList]