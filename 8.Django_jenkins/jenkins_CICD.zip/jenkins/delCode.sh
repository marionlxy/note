#!/bin/bash
# @Time    :  2019-07-25
# @Author  :  Duan.rj

jenkinsHomeDir=${1}
projectName=${2}
projectType=${3}

echoMessage(){
    case "${1}" in
        vue)
            if [[ -d ${jenkinsHomeDir}/${projectName} ]];then echo "删除旧打包项目失败!";exit 1;else echo "删除旧打包项目完成!";fi
            ;;
        node)
            if [[ -f ${jenkinsHomeDir}/${projectName}.tar.gz ]];then echo "删除旧打包项目失败!";exit 1;else echo "删除旧打包项目完成!";fi
            ;;
        java)
            echo "java"
            ;;
    esac

}


javaCodeDel(){
    # 转换成shell可遍历的字符串
    projectNameList=`echo ${projectName}|sed 's/,/ /g'`
    # 获取项目名称及项目包部署位置
    for PName in ${projectName};do
        # 删除原有项目包
        if [[ -f ${jenkinsHomeDir}/ROOT.war ]];then rm -rf ${jenkinsHomeDir}/ROOT.war
        elif [[ -f ${jenkinsHomeDir}/${PName}.war ]];then rm -rf ${jenkinsHomeDir}/${PName}.war
        elif [[ -f ${jenkinsHomeDir}/${PName}.jar ]];then rm -rf ${jenkinsHomeDir}/${PName}.jar
        elif [[ -f ${jenkinsHomeDir}/${PName}.tar.gz ]];then rm -rf ${jenkinsHomeDir}/${PName}.tar.gz
        fi
        echo "删除项目\"${PName}\"旧代码成功!"
    done

}



case "${projectType}" in
    vue)
        rm -rf ${jenkinsHomeDir}/${projectName}
        echoMessage "vue"
        ;;
    node)
        rm -rf ${jenkinsHomeDir}/${projectName}.tar.gz
        echoMessage "node"
        ;;
    java)
        javaCodeDel
        ;;
esac