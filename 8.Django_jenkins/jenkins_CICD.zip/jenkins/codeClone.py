# -*- coding: UTF-8 -*-
# @File    :  codeClone.py
# @Time    :  2019-08-01
# @Author  :  Duan.rj


import sys
import commands

tagNum = sys.argv[1]
branchType = sys.argv[2]

# bash
def bash(cmd):
    return commands.getstatusoutput(cmd)

# 检查git clone是否成功，1:错误 0:成功
def cloneOption(branchType):
    cmd = bash('git checkout %s' % (branchType))
    # if 'error: pathspec' in cmd[1]:
    if cmd[0] != 0:
        return 1
    else:
        return 0


def codeClone(tagNum, branchType):
    # 判断部署时项目是否选中
    if len(sys.argv) < 2:
        print('没有选中任何项目!')
        sys.exit(1)

    # tag部署
    if tagNum != '0':
        cmd = cloneOption(tagNum)
        print("clone Tag:\"%s\"" % tagNum)

    # 分支部署
    else:
        cmd = cloneOption(branchType)
        print("clone branch:\"%s\"" % branchType)
    # 结果反馈
    if cmd == 0:
        print("代码clone SUCCESS!")
    else:
        print("代码clone ERROR!")
        print("详细信息:")
        print(cmd[1])
        sys.exit(1)


codeClone(tagNum, branchType)