#!/bin/bash
for i in $(cat ip.txt)
do
ssh sauser@$i "sudo pvcreate  /dev/sdb"
ssh sauser@$i "sudo vgcreate vg_data /dev/sdb"
ssh sauser@$i "sudo lvcreate  -l 100%free  -n lv_data vg_data"
ssh sauser@$i "sudo mkfs.xfs /dev/vg_data/lv_data"
ssh sauser@$i "sudo mkdir -p /data"
ssh sauser@$i "sudo echo \"/dev/vg_data/lv_data      /data           xfs             defaults                0 0\" >> /etc/fstab"
ssh sauser@$i "sudo mount -a"
done
