#!/bin/bash
for i in $(cat ip.txt)
do
ssh sauser@$i "sudo useradd mysql -s /sbin/nologin"
ssh sauser@$i "sudo mkdir /myrouter"
ssh sauser@$i "sudo yum -y install wget"
ssh sauser@$i "sudo wget -P /etc/yum.repos.d  http://172.17.0.30/CentOS-YUM/Pub/YumRepoFile/CentOS7/Mysql.repo"
ssh sauser@$i "sudo yum -y install mysql"
#scp /home/sauser/ansible-roles/roles/mysql_router/file/mysql-router-commercial-2.application.properties.j2.6-application.properties.j2.application.properties.j2.el7.x86_64.rpm sauser@$i:/tmp/
#ssh sauser@$i "sudo yum -y install /tmp/mysql-router-commercial-2.application.properties.j2.6-application.properties.j2.application.properties.j2.el7.x86_64.rpm"
#ssh sauser@$i "sudo rm -f /tmp/mysql-router-commercial-2.application.properties.j2.6-application.properties.j2.application.properties.j2.el7.x86_64.rpm"
#scp lvm.sh sauser@$i:/tmp/
#ssh sauser@$i "sudo chmod +x /tmp/lvm.sh"
#ssh sauser@$i "sudo sh /tmp/lvm.sh"
#ssh sauser@$i "rm -f /tmp/lvm.sh"
#ssh sauser@$i "sudo systemctl stop mysqld"
#ssh sauser@$i "sudo yum -y remove mysql-server"
done
