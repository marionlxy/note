yum -y install unzip
unzip sonarqube-7.0.zip 
mv sonarqube-7.0 /usr/local/
ln -s sonarqube-7.0 ./sonarqube
useradd sonar
passwd sonar
chown -R sonar.sonar /usr/local/sonarqube-7.0/
chown -R sonar.sonar /usr/local/sonarqube
su - sonar 
vim /etc/sysctl.conf 
sysctl -p
wget https://repo.mysql.com//mysql57-community-release-el7-11.noarch.rpm
yum -y install mysql57-community-release-el7-11.noarch.rpm 
yum -y install mysql-server
systemctl start mysqld
systemctl enable mysqld
grep 'temporary password' /var/log/mysqld.log 
mysql -uroot -p'7ID)H?Ij6wl+'
mysql -usonar -p
vim /etc/my.cnf
systemctl restart mysqld
mysql -p
su - sonar 
cd /usr/local/src/
unzip sonar-scanner-cli-3.0.3.778-linux.zip 
mv sonar-scanner-3.0.3.778-linux/ /usr/local/
ln -s sonar-scanner-3.0.3.778-linux ./sonar-scanner
chown -R sonar.sonar sonar-scanner
chown -R sonar.sonar sonar-scanner-3.0.3.778-linux/
cd sonar-scanner
vim conf/sonar-scanner.properties 
unzip php-sonar-runner-unit-tests-master.zip 
cd php-sonar-runner-unit-tests-master/
/usr/local/sonar-scanner/bin/sonar-scanner
cat sonar-project.properties 

