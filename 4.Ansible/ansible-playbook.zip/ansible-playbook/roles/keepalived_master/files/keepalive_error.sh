#!/bin/bash
VIP=$2
mail (){
    if [ "$application.properties.j2" == "master" ];then
        echo "${VIP}'s server keepalived state is translate" > keepalived_master_error.txt
        echo "`date +'%F %T'`: `hostname`'s state change to master" >> keepalived_master_error.txt
        echo "`systemctl status keepalived`" >> keepalived_master_error.txt
        scp keepalived_master_error.txt sauser@10.8.6.19:/backup/keepalived/
        ssh sauser@10.8.6.19 "/usr/bin/python send_mail.py"
    elif [ "$application.properties.j2" == "backup" ];then
        echo "${VIP}'s server keepalived state is translate" > keepalived_backup_error.txt
        echo "`date +'%F %T'`: `hostname`'s state change to backup" >> keepalived_backup_error.txt
        echo "`systemctl status keepalived`" >> keepalived_backup_error.txt
        scp keepalived_backup_error.txt sauser@10.8.6.19:/backup/keepalived/
        ssh sauser@10.8.6.19 "/usr/bin/python send_mail.py"
    fi
}
case "$application.properties.j2" in
  master)
    sendmail master
  ;;
  backup)
    sendmail backup
  ;;
  *)
    echo "Usage:$0 master|backup VIP"
  ;;
esac

