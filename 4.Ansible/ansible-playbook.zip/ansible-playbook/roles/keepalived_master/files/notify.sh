#!/bin/bash
VIP=$2
sendmail (){
    maillist=(
        luoyinsheng@outlook.com
    )
    if [ "$application.properties.j2" == "master" ];then
        subject="${VIP}'s server keepalived state is translate"
        content="`date +'%F %T'`: `hostname`'s state change to master"
        for mail in ${maillist[*]};do
            echo $content | mail -s "$subject" $mail
             done
    elif [ "$application.properties.j2" == "backup" ];then
        subject="${VIP}'s server keepalived state is translate"
                content="`date +'%F %T'`: `hostname`'s state change to backup"
                for mail in ${maillist[*]};do
                        echo $content | mail -s "$subject" $mail
                done
    fi
}
case "$application.properties.j2" in
  master)
    sendmail master
  ;;
  backup)
    sendmail backup
  ;;
  *)
    echo "Usage:$0 master|backup VIP"
  ;;
esac
