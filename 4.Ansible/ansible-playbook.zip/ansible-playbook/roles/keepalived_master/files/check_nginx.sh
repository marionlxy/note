#!/bin/bash
port=80
nmap localhost -p $port | grep "$port/tcp open"
if [ $? -ne 0 ];then
    exit 10
fi
