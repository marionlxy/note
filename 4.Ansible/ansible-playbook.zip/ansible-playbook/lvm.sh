#!/bin/bash
disk=vdb
pvcreate  /dev/$disk
vgcreate vg_data /dev/$disk
lvcreate  -l 100%free  -n lv_data vg_data
mkfs.xfs /dev/vg_data/lv_data
echo "/dev/vg_data/lv_data      /data/mysqldata           xfs             defaults                0 0" >> /etc/fstab
mount -a
